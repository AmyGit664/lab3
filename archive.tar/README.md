# Partie3
# UE : 5AS05 
